import{c}from"./index-COmvTH6_.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],r=c("circle",e);export{r as C};
