import{c as o}from"./tanstack-C-wBXWvE.js";import{d as n}from"./query-options-2xoQ6VsH.js";function s(r,e=!0){return o({...n(r),enabled:e&&!!r.trim()})}export{s as u};
