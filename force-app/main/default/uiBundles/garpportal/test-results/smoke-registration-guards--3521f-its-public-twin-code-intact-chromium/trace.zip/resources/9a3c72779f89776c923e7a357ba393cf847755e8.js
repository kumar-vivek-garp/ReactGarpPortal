import{q as y}from"./tanstack-C-wBXWvE.js";import{W as v,z as C}from"./salesforce-lbY2Vdp8.js";import{u}from"./index-COmvTH6_.js";import"./ui-runtime-Cxxo2yWi.js";function P(){return{company:"",address1:"",address2:"",address3:"",country:"",city:"",state:"",postalCode:"",phone:""}}function m(o){const t=(o??"").split(/\r?\n/);return[t[0]?.trim()??"",t[1]?.trim()??"",t[2]?.trim()??""]}function U(o,t,i){return[o,t,i].map(a=>a.trim()).filter(Boolean).join(`
`)}function A(o,t){return o.company.trim()===t.company.trim()&&o.address1.trim()===t.address1.trim()&&o.address2.trim()===t.address2.trim()&&o.address3.trim()===t.address3.trim()&&o.country.trim()===t.country.trim()&&o.city.trim()===t.city.trim()&&o.state.trim()===t.state.trim()&&o.postalCode.trim()===t.postalCode.trim()&&o.phone.trim()===t.phone.trim()}function O(o){return{...o}}function n(o){return o?.trim()??""}const q=C`
	query PersonalInfoCountries($first: Int!) {
		uiapi {
			query {
				Country_Code__c(first: $first, orderBy: { Country__c: { order: ASC } }) {
					edges {
						node {
							Id
							Country__c @optional {
								value
							}
							Name @optional {
								value
							}
							PhoneCode__c @optional {
								value
							}
						}
					}
					pageInfo {
						hasNextPage
						endCursor
					}
				}
			}
		}
	}
`;async function M(){const t=await(await v()).graphql?.query({query:q,variables:{first:500}});if(t?.errors?.length)throw new u({messages:t.errors.map(l=>l.message)});const i=t?.data?.uiapi?.query?.Country_Code__c?.edges??[],a=new Set,e=[];for(const l of i){const s=l?.node,r=s?.Country__c?.value?.trim()||s?.Name?.value?.trim()||"";!r||a.has(r)||(a.add(r),e.push({label:r,value:r,phoneCode:s?.PhoneCode__c?.value?.trim()||null}))}return e}function T(o){const t=new Set,i=[];for(const a of o){const e=a.phoneCode?.trim();!e||t.has(e)||(t.add(e),i.push(e))}return i.sort((a,e)=>a.localeCompare(e,void 0,{numeric:!0})),i.map(a=>({label:a,value:a}))}const B=C`
	query PersonalInfoEditContact($contactId: ID!, $first: Int!) {
		uiapi {
			query {
				Contact(where: { Id: { eq: $contactId } }, first: $first) {
					edges {
						node {
							Id
							FirstName @optional {
								value
							}
							LastName @optional {
								value
							}
							Email @optional {
								value
							}
							MobilePhone @optional {
								value
							}
							Mobile_Phone_Code__c @optional {
								value
							}
							Photo_URL__c @optional {
								value
							}
							Mailing_Address_Company__c @optional {
								value
							}
							MailingStreet @optional {
								value
							}
							MailingCity @optional {
								value
							}
							MailingState @optional {
								value
							}
							MailingPostalCode @optional {
								value
							}
							MailingCountry @optional {
								value
							}
							HomePhone @optional {
								value
							}
							AccountId @optional {
								value
							}
							Account @optional {
								Id
								Billing_Address_Company__c @optional {
									value
								}
								BillingStreet @optional {
									value
								}
								BillingCity @optional {
									value
								}
								BillingState @optional {
									value
								}
								BillingPostalCode @optional {
									value
								}
								BillingCountry @optional {
									value
								}
								Phone @optional {
									value
								}
							}
						}
					}
					pageInfo {
						hasNextPage
						endCursor
					}
				}
			}
		}
	}
`;async function w(o){const t=o.trim();if(!t)throw new u({messages:["Contact Id is required."]});const a=await(await v()).graphql?.query({query:B,variables:{contactId:t,first:1},cacheControl:"no-cache"});if(a?.errors?.length)throw new u({messages:a.errors.map(I=>I.message)});const e=a?.data?.uiapi?.query?.Contact?.edges?.[0]?.node;if(!e?.Id)throw new u({messages:["Unable to load personal information."]});const[l,s,r]=m(e.MailingStreet?.value),[_,g,h]=m(e.Account?.BillingStreet?.value),d={company:n(e.Account?.Billing_Address_Company__c?.value),address1:_,address2:g,address3:h,country:n(e.Account?.BillingCountry?.value),city:n(e.Account?.BillingCity?.value),state:n(e.Account?.BillingState?.value),postalCode:n(e.Account?.BillingPostalCode?.value),phone:n(e.Account?.Phone?.value)},p={company:n(e.Mailing_Address_Company__c?.value),address1:l,address2:s,address3:r,country:n(e.MailingCountry?.value),city:n(e.MailingCity?.value),state:n(e.MailingState?.value),postalCode:n(e.MailingPostalCode?.value),phone:n(e.HomePhone?.value)},c=e.Account?.Id?.trim()||e.AccountId?.value?.trim()||null;return{contactId:e.Id,accountId:c,photoUrl:e.Photo_URL__c?.value?.trim()||null,firstName:n(e.FirstName?.value),lastName:n(e.LastName?.value),email:n(e.Email?.value),mobilePhoneCode:n(e.Mobile_Phone_Code__c?.value),mobilePhone:n(e.MobilePhone?.value),billing:c?d:P(),mailing:p,sameAsBilling:c?A(d,p):!1}}const f={all:["personal-info"],countries:["personal-info","countries"],edit:o=>["personal-info","edit",o]},$=y({queryKey:f.countries,queryFn:M,staleTime:5*6e4,retry:!1,meta:{toastError:!0,errorTitle:"Unable to load countries"}});function Q(o){return y({queryKey:f.edit(o),queryFn:()=>w(o),enabled:!!o.trim(),staleTime:3e4,retry:!1,meta:{toastError:!0,errorTitle:"Unable to load personal information"}})}export{T as a,$ as b,O as c,Q as d,P as e,U as j,f as p};
