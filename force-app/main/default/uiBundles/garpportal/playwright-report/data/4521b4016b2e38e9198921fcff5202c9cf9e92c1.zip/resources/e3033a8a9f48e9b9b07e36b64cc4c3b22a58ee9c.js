const t={mass:.8,tension:420,friction:30},e={from:{opacity:0},enter:{opacity:1},leave:{opacity:0},config:t,exitBeforeEnter:!0};export{e as T};
