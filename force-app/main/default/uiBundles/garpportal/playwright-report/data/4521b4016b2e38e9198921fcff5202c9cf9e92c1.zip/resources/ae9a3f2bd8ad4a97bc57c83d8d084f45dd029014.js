import{c as r}from"./tanstack-C-wBXWvE.js";import"./ui-runtime-Cxxo2yWi.js";import{bz as o}from"./index-COmvTH6_.js";function u(){return r(o)}export{u};
