import{c as r}from"./tanstack-C-wBXWvE.js";import"./ui-runtime-Cxxo2yWi.js";import{ab as e}from"./index-COmvTH6_.js";function u(){return r(e)}export{u};
